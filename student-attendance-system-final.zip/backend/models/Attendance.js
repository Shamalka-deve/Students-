const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
  studentId: String,
  date: { type: Date, default: Date.now },
  status: { type: String, enum: ["Present", "Absent"], default: "Present" },
  grade: String
});

module.exports = mongoose.model("Attendance", attendanceSchema);
