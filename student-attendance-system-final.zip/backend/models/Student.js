const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  studentId: { type: String, unique: true },
  name: String,
  address: String,
  parentEmail: String,
  parentPhone: String,
  grade: String
});

module.exports = mongoose.model("Student", studentSchema);
