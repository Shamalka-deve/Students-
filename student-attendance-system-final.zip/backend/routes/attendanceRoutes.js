const express = require("express");
const router = express.Router();
const Attendance = require("../models/Attendance");

router.post("/mark", async (req, res) => {
  try {
    const { studentId, status, grade } = req.body;
    const attendance = new Attendance({ studentId, status, grade });
    await attendance.save();
    res.json(attendance);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:grade", async (req, res) => {
  const { grade } = req.params;
  const records = await Attendance.find({ grade });
  res.json(records);
});

module.exports = router;
