const express = require("express");
const router = express.Router();
const Student = require("../models/Student");

router.post("/register", async (req, res) => {
  try {
    const { name, address, parentEmail, parentPhone, grade } = req.body;
    const studentId = "STU" + Date.now();
    const newStudent = new Student({ studentId, name, address, parentEmail, parentPhone, grade });
    await newStudent.save();
    res.json(newStudent);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/", async (req, res) => {
  const students = await Student.find();
  res.json(students);
});

module.exports = router;
