import React, { useState, useEffect } from "react";
import axios from "axios";
import emailjs from "@emailjs/browser";

const App = () => {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: "", address: "", parentEmail: "", parentPhone: "", grade: "" });

  useEffect(() => {
    axios.get("http://localhost:5000/api/students").then(res => setStudents(res.data));
  }, []);

  const registerStudent = async () => {
    const res = await axios.post("http://localhost:5000/api/students/register", form);
    setStudents([...students, res.data]);
  };

  const markAttendance = async (student, status) => {
    await axios.post("http://localhost:5000/api/attendance/mark", { studentId: student.studentId, status, grade: student.grade });

    if (status === "Absent") {
      emailjs.send("service_8icfipw", "template_wcqc1mb", {
        to_email: student.parentEmail,
        student_name: student.name,
        grade: student.grade,
        status: status
      }, "H_U9vM_txEqOExCMZ");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>📚 Student Attendance System</h1>

      <h2>Register Student</h2>
      <input placeholder="Name" onChange={e => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Address" onChange={e => setForm({ ...form, address: e.target.value })} />
      <input placeholder="Parent Email" onChange={e => setForm({ ...form, parentEmail: e.target.value })} />
      <input placeholder="Parent Phone" onChange={e => setForm({ ...form, parentPhone: e.target.value })} />
      <input placeholder="Grade" onChange={e => setForm({ ...form, grade: e.target.value })} />
      <button onClick={registerStudent}>Register</button>

      <h2>Students List</h2>
      {students.map(stu => (
        <div key={stu.studentId}>
          <b>{stu.name}</b> ({stu.grade}) - {stu.parentEmail}
          <button onClick={() => markAttendance(stu, "Present")}>Present</button>
          <button onClick={() => markAttendance(stu, "Absent")}>Absent</button>
        </div>
      ))}
    </div>
  );
};

export default App;
